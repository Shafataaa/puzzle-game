const shapeLevels = {
  1: [['🔵','🔺','🔵'],['🔺','🔵','🔺'],['🔵','🔺','🔵']],
  2: [['🔺','🔵','🔺'],['🔵','🔺','🔵'],['🔺','🔵','🔺']],
  3: [['🟢','🔵','🔺'],['🔺','🟢','🔵'],['🔵','🔺','🟢']],
  4: [['🔵','🟢','🔵'],['🟢','🔺','🟢'],['🔵','🟢','🔵']],
  5: [['🔺','🟢','🔵'],['🟢','🔵','🔺'],['🔵','🔺','🟢']]
};

const patternLevels = {
  1: [['◼','◆','◼'],['◆','◼','◆'],['◼','◆','◼']],
  2: [['◆','◼','◆'],['◼','◆','◼'],['◆','◼','◆']],
  3: [['⬟','◼','◆'],['◆','⬟','◼'],['◼','◆','⬟']],
  4: [['◼','⬟','◼'],['⬟','◆','⬟'],['◼','⬟','◼']],
  5: [['◆','⬟','◼'],['⬟','◼','◆'],['◼','◆','⬟']]
};

const numberLevels = {
  1: [['1','2','3'],['4','5','6'],['7','8','9']],
  2: [['2','4','6'],['1','3','5'],['7','9','8']],
  3: [['3','1','2'],['6','5','4'],['9','8','7']],
  4: [['7','8','9'],['1','2','3'],['4','5','6']],
  5: [['5','1','9'],['2','6','3'],['4','7','8']]
};

let currentZone = '';
let currentLevel = 1;
let selectedSymbol = '';
let currentSolution = [];

function enterWorld(world) {
  currentZone = world;
  currentLevel = 1;
  document.getElementById("world-container").style.display = "none";
  document.getElementById("level-select").style.display = "block";

  const titles = {
    shape: "Shape Zone",
    pattern: "Pattern World",
    number: "Number Sector"
  };

  document.getElementById("zone-title").innerText = titles[world];
  const btns = document.getElementById("level-buttons");
  btns.innerHTML = "";

  for (let i = 1; i <= 5; i++) {
    const btn = document.createElement("button");
    btn.textContent = `Level ${i}`;
    btn.onclick = () => startLevel(i);
    btns.appendChild(btn);
  }
}

function goBack() {
  document.getElementById("level-select").style.display = "none";
  document.getElementById("world-container").style.display = "block";
}

function exitGame() {
  document.getElementById("game-container").style.display = "none";
  document.getElementById("level-select").style.display = "block";
}

function selectShape(symbol) {
  selectedSymbol = symbol;
}

function startLevel(level) {
  currentLevel = level;
  document.getElementById("level-select").style.display = "none";
  document.getElementById("game-container").style.display = "block";

  let zoneTitle = {
    shape: "🔺 Shape Zone",
    pattern: "🧩 Pattern World",
    number: "🔢 Number Sector"
  };

  document.getElementById("game-title").innerText = `${zoneTitle[currentZone]} - Level ${currentLevel}`;

  if (currentZone === "shape") {
    selectedSymbol = '🔵';
    currentSolution = shapeLevels[level];
    showOptions(['🔵','🔺','🟢']);
    document.getElementById("game-instruction").innerText = "Isi bentuk sesuai pola!";
  } else if (currentZone === "pattern") {
    selectedSymbol = '◼';
    currentSolution = patternLevels[level];
    showOptions(['◼','◆','⬟']);
    document.getElementById("game-instruction").innerText = "Isi simbol sesuai pola!";
  } else if (currentZone === "number") {
    selectedSymbol = '1';
    currentSolution = numberLevels[level];
    showOptions(['1','2','3','4','5','6','7','8','9']);
    document.getElementById("game-instruction").innerText = "Isi angka sesuai urutan!";
  }

  createGrid();
}

function showOptions(options) {
  const container = document.getElementById("shape-options");
  container.innerHTML = "";
  options.forEach(symbol => {
    const btn = document.createElement("button");
    btn.textContent = symbol;
    btn.onclick = () => selectShape(symbol);
    container.appendChild(btn);
  });
}

function createGrid() {
  const grid = document.getElementById("shape-grid");
  grid.innerHTML = "";
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const cell = document.createElement("div");
      cell.className = "cell";
      cell.dataset.row = r;
      cell.dataset.col = c;
      cell.onclick = () => {
        cell.textContent = selectedSymbol;
        checkWin();
      };
      grid.appendChild(cell);
    }
  }
}

function checkWin() {
  const cells = document.querySelectorAll(".cell");
  let correct = true;

  cells.forEach(cell => {
    const r = cell.dataset.row;
    const c = cell.dataset.col;
    if (cell.textContent !== currentSolution[r][c]) {
      correct = false;
    }
  });

  if (correct) {
    setTimeout(() => {
      if (currentLevel < 5) {
        alert(`✅ Level ${currentLevel} selesai!`);
        currentLevel++;
        startLevel(currentLevel);
      } else {
        alert("🏁 Kamu menyelesaikan semua level!");
        exitGame();
      }
    }, 300);
  }
}
